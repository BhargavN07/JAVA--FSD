package Phase1PracticeProject;

public class array {
	public static void main(String[] args) {

		//single-dimensional array
		int a[]= {11,12,13,14,15};
		for(int i=0;i<5;i++) {
		System.out.println("Elements of array a: "+a[i]);
		}


		//multidimensional array
		int[][] b = {
		            {4, 4, 5}, 
		            {3, 8, 6,}};
		      
		      System.out.println("\nLength of row 1: " + b[0].length);
		      }
		}
