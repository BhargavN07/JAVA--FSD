package AssistedPrctice;

import java.util.Scanner;
import java.util.Arrays;  
class BinarySearch{  
    public static void main(String args[]){  
        int arr[] = {17,24,13,46,50};  
        int key = 30;  
        int result = Arrays.binarySearch(arr,key);  
        if (result < 0)  
            System.out.println("Element is not found!");  
        else  
            System.out.println("Element is found at index: "+result);  
    }  
}  