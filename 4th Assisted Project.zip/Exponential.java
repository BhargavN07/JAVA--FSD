package AssistedPrctice;

import java.util.Arrays;

public class Exponential {

public static  void main(String[] args){

    int[] arr = {22,45,66,12,23,10};
    int length= arr.length;
    int value = 22;
    int Temp = expSearch(arr,length,value);

    if(Temp<0)
    {

       System.out.println( "Element is not present ");

    }else {

        System.out.println( "Element is  present and its index is :"+Temp);
    }

        }

        public static int expSearch(int[] arr ,int length, int value )
        {

        if(arr[0]==value){
            return 0;
            }
        int i=1;
        while(i<length && arr[i]<=value){

            i=i*2;
        }
        return Arrays.binarySearch(arr,i/2,Math.min(i,length),value);
        }
}


