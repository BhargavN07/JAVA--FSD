import { Attendance } from './attendance';

describe('Attendance', () => {
  it('should create an instance', () => {
    expect(new Attendance()).toBeTruthy();
  });
});
