export class Attendance {

        empId:number;
        date:string;
        status:string;
    
}
