package Phase1PracticeProject;

import java.util.*;

public class collectors {
	public static void main(String[] args) 
	{
		
		//arraylist
		System.out.println("ArrayList");
		ArrayList<String> temp=new ArrayList<String>();   
	      temp.add("Chennai");
	      temp.add("Pune");    	   
	      System.out.println(temp);  
		
		//vector
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vec = new Vector();
	      vec.addElement(07); 
	      vec.addElement(77); 
	      System.out.println(vec);
		
		//linkedlist
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> 
	      name=new LinkedList<String>();  
	      name.add("siva");  
	      name.add("bala");  	      
	      Iterator<String> itr=name.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	       
	       //hashset
	       System.out.println("\n");
	       System.out.println("HashSet");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(10);  
	       set.add(11);  
	       set.add(14);
	       set.add(13);
	       System.out.println(set);
	       
	       //linkedhashset
	       System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(8);  
	       set2.add(4);  
	       set2.add(6);
	       set2.add(2);	       
	       System.out.println(set2);
	      	} 
	      }  
	}


